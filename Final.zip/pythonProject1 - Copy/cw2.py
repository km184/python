'''Importing the neccesary files'''

import sys
import os
from tkinter import messagebox
import Continents
from graphviz import Digraph
import httpagentparser
# This import module handles data ingestion
import DataHandling
import collections
import tree_view
import numpy as np
import matplotlib.pyplot as plt

try:
    import Tkinter as tk
except ImportError:
    import tkinter as tk

try:
    import ttk

    py3 = False
except ImportError:
    import tkinter.ttk as ttk

    py3 = True

import cw2support1, cw2_support

'''
Start engine for the gui
The method initiates the construction of the gui and keeps the maainloop running

'''

print(__name__)


def vp_start_gui():
    """Starting point when module is the main routine."""
    global val, w, root
    root = tk.Tk()
    cw2support1.set_Tk_var()
    top = Toplevel1(root)
    cw2support1.init(root, top)

    root.mainloop()


w = None


def create_Toplevel1(rt, *args, **kwargs):
    '''Starting point when module is imported by another module.
       Correct form of call: 'create_Toplevel1(root, *args, **kwargs)' .'''
    global w, w_win, root
    # rt = root
    root = rt
    w = tk.Toplevel(root)
    cw2support1.set_Tk_var()
    top = Toplevel1(w)
    cw2support1.init(w, top, *args, **kwargs)
    return (w, top)


'''This method dstroys the gui'''


def destroy_Toplevel1():
    global w
    w.destroy()
    w = None


'''
Blue print for the gui
This is where the instructions for manufacturing the gui are 
'''


class Toplevel1:
    i = None
    """Constructor for the GUI"""

    def __init__(self, top=None):
        '''This class configures and populates the toplevel window.
           top is the toplevel containing window.'''
        _bgcolor = '#d9d9d9'  # X11 color: 'gray85'
        _fgcolor = '#000000'  # X11 color: 'black'
        _compcolor = '#d9d9d9'  # X11 color: 'gray85'
        _ana1color = '#d9d9d9'  # X11 color: 'gray85'
        _ana2color = '#ececec'  # Closest X11 color: 'gray92'
        self.style = ttk.Style()
        if sys.platform == "win32":
            self.style.theme_use('winnative')
        self.style.configure('.', background=_bgcolor)
        self.style.configure('.', foreground=_fgcolor)
        self.style.configure('.', font="TkDefaultFont")
        self.style.map('.', background=
        [('selected', _compcolor), ('active', _ana2color)])

        top.geometry("600x450+323+176")
        top.minsize(120, 1)
        top.maxsize(1370, 749)
        top.resizable(1, 1)
        top.title("Issu Data App")
        top.configure(background="#d9d9d9")
        top.configure(cursor="arrow")

        data = None
        self.TLabel1 = ttk.Label(top)
        self.TLabel1.place(relx=0.38, rely=0.067, height=19, width=125)
        self.TLabel1.configure(background="#00ffff")
        self.TLabel1.configure(foreground="#000000")
        self.TLabel1.configure(font="TkDefaultFont")
        self.TLabel1.configure(borderwidth="10")
        self.TLabel1.configure(relief="flat")
        self.TLabel1.configure(anchor='w')
        self.TLabel1.configure(justify='left')
        self.TLabel1.configure(text='''Issuu Data Application''')
        self.TLabel1.configure(compound='top')
        self.TLabel1.configure(cursor="arrow")

        self.menubar = tk.Menu(top, font="TkMenuFont", bg=_bgcolor, fg=_fgcolor)
        top.configure(menu=self.menubar)

        self.TButton2 = ttk.Button(top)
        self.TButton2.place(relx=0.083, rely=0.844, height=25, width=76)
        self.TButton2.configure(command=lambda: self.country_views())
        self.TButton2.configure(takefocus="")
        self.TButton2.configure(text='''Task 2a''')

        self.TButton3 = ttk.Button(top)
        self.TButton3.place(relx=0.25, rely=0.844, height=25, width=76)
        self.TButton3.configure(command=lambda: self.browser_views())
        self.TButton3.configure(takefocus="")
        self.TButton3.configure(text='''Task 3b''')

        self.TButton4 = ttk.Button(top)
        self.TButton4.place(relx=0.55, rely=0.844, height=25, width=76)
        self.TButton4.configure(command=lambda: self.top_10_tree())
        self.TButton4.configure(takefocus="")
        self.TButton4.configure(text='''Task 4''')

        self.TButton6 = ttk.Button(top)
        self.TButton6.place(relx=0.4, rely=0.844, height=25, width=76)
        self.TButton6.configure(command=lambda: self.view_by_continents())
        self.TButton6.configure(takefocus="")
        self.TButton6.configure(text='''Task 2b''')

        self.TButton7 = ttk.Button(top)
        self.TButton7.place(relx=0.37, rely=0.45, height=25, width=76)
        self.TButton7.configure(command=lambda: [self.bar(), self.import_data()])
        self.TButton7.configure(takefocus="")
        self.TButton7.configure(text='''Import Data''')

        self.TButton8 = ttk.Button(top)
        self.TButton8.place(relx=0.37, rely=0.76, height=25, width=76)
        self.TButton8.configure(command=lambda: self.likes1())
        self.TButton8.configure(takefocus="")
        self.TButton8.configure(text='''Task 5d''')

        self.TButton5 = ttk.Button(top)
        self.TButton5.place(relx=0.75, rely=0.844, height=25, width=76)
        self.TButton5.configure(command=lambda: self.viewAlsoLikesGraph())
        self.TButton5.configure(takefocus="")
        self.TButton5.configure(text='''Task 6''')

        self.uuid = ttk.Entry(top)
        self.uuid.place(relx=0.217, rely=0.2, relheight=0.047, relwidth=0.61)
        self.uuid.configure(takefocus="")
        self.uuid.configure(cursor="fleur")

        self.user_uuid = ttk.Entry(top)
        self.user_uuid.place(relx=0.217, rely=0.26, relheight=0.047, relwidth=0.61)
        self.user_uuid.configure(takefocus="")
        self.user_uuid.configure(cursor="fleur")

        self.Filename = ttk.Entry(top)
        self.Filename.place(relx=0.217, rely=0.32, relheight=0.047, relwidth=0.31)
        self.Filename.configure(takefocus="")
        self.Filename.configure(cursor="fleur")

        self.TLabel2 = ttk.Label(top)
        self.TLabel2.place(relx=0.1, rely=0.2, height=19, width=55)
        self.TLabel2.configure(background="#d9d9d9")
        self.TLabel2.configure(foreground="#000000")
        self.TLabel2.configure(font="TkDefaultFont")
        self.TLabel2.configure(relief="flat")
        self.TLabel2.configure(anchor='w')
        self.TLabel2.configure(justify='left')
        self.TLabel2.configure(text='''UUID''')

        self.TLabel3 = ttk.Label(top)
        self.TLabel3.place(relx=0.1, rely=0.26, height=19, width=55)
        self.TLabel3.configure(background="#d9d9d9")
        self.TLabel3.configure(foreground="#000000")
        self.TLabel3.configure(font="TkDefaultFont")
        self.TLabel3.configure(relief="flat")
        self.TLabel3.configure(anchor='w')
        self.TLabel3.configure(justify='left')
        self.TLabel3.configure(text='''USER_ID''')

        self.TLabel4 = ttk.Label(top)
        self.TLabel4.place(relx=0.1, rely=0.32, height=19, width=55)
        self.TLabel4.configure(background="#d9d9d9")
        self.TLabel4.configure(foreground="#000000")
        self.TLabel4.configure(font="TkDefaultFont")
        self.TLabel4.configure(relief="flat")
        self.TLabel4.configure(anchor='w')
        self.TLabel4.configure(justify='left')
        self.TLabel4.configure(text='''Source''')

        self.TLabel3 = ttk.Label(top)
        self.TLabel3.place(relx=0.4, rely=0.4, height=19, width=500)
        self.TLabel3.configure(background="#d9d9d9")
        self.TLabel3.configure(foreground="#000000")
        self.TLabel3.configure(font="TkDefaultFont")
        self.TLabel3.configure(relief="flat")
        self.TLabel3.configure(anchor='w')
        self.TLabel3.configure(justify='left')
        self.TLabel3.configure(text='''Step 1''')

        self.TProgressbar1 = ttk.Progressbar(top)
        self.TProgressbar1.place(relx=0.217, rely=0.644, relwidth=0.6
                                 , relheight=0.0, height=22)
        self.TProgressbar1.configure(length="360")

    '''Initial data is empty'''
    dfd = None
    """This method is responsible for importing the data to be used in the analysis"""

    def import_data(self):
        print('importing')
        self.dfd = self.get_data()

    """This is an animation progress bar which loads up before the data is imported"""

    def bar(self):
        import time
        if len(self.Filename.get()) != 0:
            self.TProgressbar1['value'] = 20
            root.update_idletasks()

            self.TProgressbar1['value'] = 40
            root.update_idletasks()

            self.TProgressbar1['value'] = 50
            root.update_idletasks()
            time.sleep(1)

            self.TProgressbar1['value'] = 60
            root.update_idletasks()

            self.TProgressbar1['value'] = 80
            root.update_idletasks()
            time.sleep(1)

            self.TProgressbar1['value'] = 100

            self.TProgressbar1.pack(pady=10)

    import pandas as pd
    """
    This method works with import data to complete the data importing process
    It gets the file name as an argument from the graphical user interface and passes it to the data handling 
    module where the file of interest is processed into chunks
    """

    def get_data(self):
        try:
            data_file = self.Filename.get().strip()
            messagebox.showinfo('Issuu Data Management Team',
                                'Please wait while we fetch your processed result, this may take a while depending on the size of data')
            Data = DataHandling.DataHandling().read_data(data_file)
            return Data
        except ValueError as err:
            messagebox.showerror('File name empty', 'Please specify the correct file')

    """This method gets the Document id from the input field"""

    def get_uuid(self):
        uui = self.uuid.get().strip()
        return uui

    """
    This method plots a histogram of the different countries for the visitors of a document
    
    Keyword arguments:
    The function fetches the document id from the input field.
    
    
    """

    def country_views(self):
        uui = self.uuid.get().strip()
        if len(uui) == 0:
            messagebox.showerror('Visitor id is missing', 'It seems like you forgot to specify the user/visitor.')
            return
        coutries = self.dfd[self.dfd.env_doc_id == uui]['visitor_country']
        plt.xlabel('Country')
        plt.ylabel('Count')
        plt.hist(coutries)
        plt.show()

    """
        This method plots a histogram of the different browsers for the visitors who visited the site

        Keyword arguments:
        none required


        """

    def browser_views(self):
        try:

            browsers = self.dfd.visitor_useragent.values
            listitize_browsers = list(browsers)
            list_of_browsers_processed = []
            for user_ag in listitize_browsers:
                s = str(user_ag)
                s1 = httpagentparser.simple_detect(s)[1].split(" ")[0][0:4]
                list_of_browsers_processed.append(s1)
            plt.xlabel('Browsers')
            plt.xticks(rotation=90)
            plt.ylabel('Count')
            plt.hist(list_of_browsers_processed, color="skyblue", ec="red")
            plt.show()
        except AttributeError as AE:
            messagebox.showinfo('File name empty', 'Input file not specified')

    """
            This method displays the tree view of the even read_time for different users sorted by the the top 10

            Keyword arguments:
            none required


            """

    def top_10_tree(self):
        try:
            print(type(self.dfd))
            cols_to_keep = ['visitor_uuid', 'event_readtime']
            time_vs_user = self.dfd[cols_to_keep]
            grouped = time_vs_user.groupby('visitor_uuid')
            final = grouped['event_readtime'].agg(np.sum)
            df = final.to_frame()
            top_10 = df.nlargest(10, 'event_readtime')
            tuples = tree_view.create_Toplevel1(None)  # This is how i instantiated the gui

            tuples[1].Scrolledtreeview1.insert(parent='', index='end', text=top_10.iloc[:, 0:1], values=2)
            tree_view.vp_start_gui()

        except TypeError as TE:
            messagebox.showerror('File Not Specified',
                                 'Dear user, to view Top 10 files please ensure you have specified the correct file within the same directory as you app')

    """
           This method plots a histogram of the different continents for the visitors who visited the site

           Keyword arguments:
           none required


           """

    def view_by_continents(self):
        try:
            uui = self.uuid.get().strip()
            coutries = self.dfd[self.dfd.env_doc_id == uui]['visitor_country']
            only_countries = coutries.to_frame()
            lisatable = only_countries['visitor_country'].to_list()
            my_list_of_continents = []
            for country in lisatable:
                if country in Continents.cntry_to_cont.keys():
                    value_of_continent = Continents.cntry_to_cont[country]
                    print(value_of_continent)
                    my_list_of_continents.append(value_of_continent)
            plt.hist(my_list_of_continents)
            plt.xlabel('Continents')
            plt.ylabel('Count')
            plt.show()
        except AttributeError as AE:
            messagebox.showerror('None Detected',
                                 'Please ensure that you have specified the following: correct file, correct Doc id')

    '''
    This function returns all the documents read by a particular user
    KeyWord Arguemts:  Visitor uuid
    
    
    '''

    def get_all_Doc(self, v_uuid):

        filter = self.dfd['visitor_uuid'] == v_uuid
        read_filter = self.dfd['event_type'] == 'read'
        dfd_filtered = self.dfd[filter & read_filter]
        user_ids = dfd_filtered['subject_doc_id']
        mylist = list(dict.fromkeys(user_ids))
        return list(mylist)

    '''This function gets all the visitors who read a document
    
    keyword arguments: document id
    '''

    def get_all_visitors(self, d_uuid):

        filter = self.dfd['subject_doc_id'] == d_uuid
        read_filter = self.dfd['event_type'] == 'read'
        dfd_filtered = self.dfd[filter & read_filter]
        user_ids = dfd_filtered['visitor_uuid']
        mylist = list(dict.fromkeys(user_ids))

        return list(mylist)

    def likes1(self, *args):
        try:
            d_uuid = str(self.uuid.get().strip())
            all_visitors = self.get_all_visitors(d_uuid)
            print('All visitors who read the above document with id {0} are:'.format(d_uuid), all_visitors)
            print('')
            print('')
            print('')
            docs = []
            for visitor in all_visitors:
                document_container = self.get_all_Doc(
                    visitor)  # for every vistor who read the document we get other documents they read
                for doc_inner in document_container:
                    docs.append(doc_inner)
                print(visitor, ' reads the following documents', document_container)  # document
                cleanedList = [x for x in docs if str(x) != 'nan']  # we remove NA and the document of interest
                cleanedList1 = [final for final in cleanedList if str(final) != d_uuid]  # remove the document interent
                a_counter = collections.Counter(cleanedList1)
                sorted_by_count = a_counter.most_common()
                print('Sorted by top readers')
            for tup in sorted_by_count:
                print("Document:", tup[0], "  ""number of Reads:", tup[1])
        except UnboundLocalError:
            messagebox.showerror('Document Not recognised','Document may not exist, please try again')




    '''This functions computes the size of the data'''

    def get_size_of_data(self):
        size = self.dfd.index.stop
        if int(size) // 1000000 != 0:
            size = str(self.dfd.index.stop // 1000000) + 'm lines'
            return size
        elif int(size) // 1000 != 0:
            size = str(self.dfd.index.stop // 1000) + 'k lines'
            return size
        else:
            size = str(self.dfd.index.stop) + ' lines'
            return size

    '''This method enables visualisation of the also like graph by making use of the get_all_visitors and get_all_doc
     methods
     In this method first get the size of the data for labelling along the edge
     
     
     '''

    def viewAlsoLikesGraph(self):
        try:
            size = self.get_size_of_data()  # size of the data to display along edge
            dot = Digraph(name='The Graph')
            dot.node('Readers', shape='none')
            dot.node('Documents', shape='none')
            dot.edge('Readers', 'Documents', label=('Size: %s' % size))
            d_uuid = str(self.uuid.get().strip())
            v_u = self.user_uuid.get().strip()
            if len(v_u) != 0:
                document_to_remove = self.get_all_Doc(v_u)
                print(document_to_remove)
                document_to_remove.remove(d_uuid)
            else:
                document_to_remove = []
            all_visitors = self.get_all_visitors(d_uuid)
            if len(all_visitors) == 0:
                messagebox.showinfo('No visitors',
                                    'Oh, seems like no one read that documents,please check you typed it correctly')
                return
            for visitor in all_visitors:
                if len(v_u) != 0 and visitor == self.user_uuid.get().strip():
                    dot.node(str(visitor)[-4:], fillcolor='green', style='filled')
                    document_container = self.get_all_Doc(visitor)
                else:
                    #
                    dot.node(str(visitor)[-4:], fillcolor='red', style='filled')
                    document_container = self.get_all_Doc(visitor)
                cleanedList1 = [x for x in document_container if str(x) != 'nan']
                cleanedList = [x for x in cleanedList1 if x not in document_to_remove]
                for doc in cleanedList:
                    if doc == d_uuid:
                        dot.node(str(doc)[-4:], fillcolor='green', style='filled')
                        dot.edge(str(visitor)[-4:], str(doc)[-4:])
                    else:
                        dot.node(str(doc)[-4:], fillcolor='blue', style='filled')
                        dot.edge(str(visitor)[-4:], str(doc)[-4:])
            dot.render('Also_likes_graph', view=True)
        except AttributeError as AE:
            messagebox.showerror('Something seems wrong',
                                 'Did you pass in the file? The document id? please check the user id(optional) as last resort')
        except ValueError as v:
            messagebox.showerror('doc_id or user_id not correct', 'please provide correct id')
        except NameError as N:
            print('error')


'''
Entry point: The program checks if more than 2 commandline arguments have been parsed.If that is the case
the program will use the command line arguments to execute the program
otherwise the  GUI will fire up and the user will have to enter the values manully




'''
from optparse import OptionParser

if __name__ == '__main__':
    if len(sys.argv) >= 2:

        optionsParser = OptionParser(add_help_option=False)
        optionsParser.add_option('-u', default=" ")
        optionsParser.add_option('-d', default=" ")
        optionsParser.add_option('-t')
        optionsParser.add_option('-f')
        (options, args) = optionsParser.parse_args()

        top = create_Toplevel1(None)[1]
        top.user_uuid.insert(0, str(options.u))
        top.uuid.insert(0, str(options.d))
        task_id = str(options.t)
        top.Filename.insert(0, str(options.f))
        top.import_data()
        print(sys.argv)
        if task_id == '2a':
            top.country_views()
        elif task_id == '2b':
            top.view_by_continents()
        elif task_id == '3b':
            top.browser_views()
        elif task_id == '4':
            top.top_10_tree()

        elif task_id == '5d':
            top.likes1()
        elif task_id == '6':
            top.viewAlsoLikesGraph()
        elif task_id == '7':
            top.viewAlsoLikesGraph()
            vp_start_gui()


    else:
        vp_start_gui()
