import unittest
from View import main


# inherit
class Test_Main(unittest.TestCase):
    def test_importdata(self):
        fileName = 'issuu_cw2.json'
        obj = main.create_Toplevel1(None)[1]
        obj.Filename.insert(0, fileName)
        result = obj.import_data()
        print(result)
        expected = obj.dfd
        self.assertIsNotNone(expected)
    """This is a test for getting the visitors who read a doccument"""
    def test_visitors(self):
        doc_id = '140222143932-91796b01f94327ee809bd759fd0f6c76'
        obj = main.create_Toplevel1(None)[1]
        fileName = 'issuu_cw2.json'
        obj.Filename.insert(0, fileName)
        result = obj.import_data()
        obj.uuid.insert(0, doc_id)
        result = obj.get_all_visitors(doc_id)
        print(len(result))
        self.assertIsNotNone(result)
    """test for getting the documents read by a visitor"""
    def test_getdocs(self):
        visitor_id = 'ade7e1f63bc83c66'
        obj = main.create_Toplevel1(None)[1]
        fileName = 'issuu_cw2.json'
        obj.Filename.insert(0, fileName)
        result = obj.import_data()
        obj.user_uuid.insert(0,visitor_id)
        result = obj.get_all_Doc(visitor_id)
        print(len(result))
        self.assertIsNotNone(result)

    def test_dataSize(self):
        obj = main.create_Toplevel1(None)[1]
        fileName = 'issuu_cw2.json'
        obj.Filename.insert(0, fileName)
        result = obj.import_data()
        result = obj.get_size_of_data()
        print(len(result))
        self.assertEqual(result,'10k lines')

if __name__ == '__main__':
    unittest.main()
