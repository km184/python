import click

@click.command()
@click.option('--string')
def cli(string):
    print(string)
