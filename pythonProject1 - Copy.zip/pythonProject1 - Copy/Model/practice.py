import requests
import pandas as pd
from bs4 import BeautifulSoup
import json
data = requests.get("http://www.macs.hw.ac.uk/~hwloidl/Courses/F21SC/issuu_sample.json").text
print(data)



for line in data.splitlines():
    json_form=json.loads(line)
    print(json_form['visitor_uuid'])
pandas_data=pd.read_json('../View/issuu_sample.json', lines=True)
