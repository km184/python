from dask import dataframe as dd
import matplotlib.pyplot as plt

def read_data(url):
    dfd = dd.read_json(
        url,
        lines=True,
        blocksize='600MB'
          ,sample=2**26
    )
    print(type(dfd))
    return  dfd




#get_histogram_of_browsers()