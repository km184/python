# This class is for data handling
from tkinter import messagebox

import pandas as pd
from View import GUI_UPDATE2 as Gui
import matplotlib.pyplot as plt


class DataHandling():
    def __init__(self):
        pass

    # Define an empty DataFrame  to contain all the Data read in chunks
    Data = pd.DataFrame()
    '''
    This method reads in data in just by first creating a json reader object
    The chunks are then concatenated into a final dataframe for final insights
    
    '''

    def read_data(self, fileName):
        self.Data = pd.read_json(fileName, lines=True, chunksize=100000)
        Chunks = []  # this list will contain the data chuncks for processing
        count = 0
        for chunk in self.Data:
            print(count)
            Chunks.append(chunk)
            count = count + 1  # This basically tells us that we are processing the next chunk
        df2 = pd.concat(Chunks, ignore_index=True)
        messagebox.showinfo('Sucess', 'Data is ready to visualise')
        return df2

    def get_data(self):
        return self.Data

    '''This method returns the description of the Data ingested '''

    def get_Data_Summary(self):
        print(self.Data.describe())
