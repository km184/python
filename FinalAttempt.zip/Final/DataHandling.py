# This class is for data handling
from tkinter import messagebox
'''Importing the neccesary modules for data processing'''
import pandas as pd
import main as Gui
import matplotlib.pyplot as plt

'''This class is a blueprint for the data importing functionality'''
class DataHandling():
    """The constructor  is not doing anything"""
    def __init__(self):
        pass

    # Define an empty DataFrame  to contain all the Data read in chunks
    Data = pd.DataFrame()
    '''
    This method reads in data in just by first creating a json reader object
    The chunks are then concatenated into a final dataframe for final insights
    The chucksize is 100k because it was evident that the computer can handle that much per unit time
    '''

    def read_data(self, fileName):
        self.Data = pd.read_json(fileName, lines=True, chunksize=100000)
        Chunks = []  # this list will contain the data chuncks for processing
        count = 0
        for chunk in self.Data:
            Chunks.append(chunk)
        df2 = pd.concat(Chunks, ignore_index=True)
        messagebox.showinfo('Sucess', 'Data is ready to visualise')
        return df2




